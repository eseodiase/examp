import React from 'react';
import ReactDOM from 'react-dom';

import './style.css';

ReactDOM.render(
<div>
<h1>Ese Stack</h1>
<p>Start React 17</p>
<p>Start Now</p>
</div>,
document.getElementById("root")
);
